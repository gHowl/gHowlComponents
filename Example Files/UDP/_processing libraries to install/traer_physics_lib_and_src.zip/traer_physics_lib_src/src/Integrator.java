package traer.physics;

public interface Integrator 
{
	public void step( float t );
}
